const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));

const players = new Map(); // socket.id -> { name, gems, room }
const rooms = new Map();   // room code -> { host, players, stake, status }

function code() {
  return crypto.randomBytes(3).toString("hex").toUpperCase();
}
function publicRoom(roomCode) {
  const room = rooms.get(roomCode);
  if (!room) return null;
  return {
    code: roomCode,
    stake: room.stake,
    status: room.status,
    players: room.players.map(id => {
      const p = players.get(id);
      return p ? { name: p.name, color: p.color || null, ready: !!p.ready } : null;
    }).filter(Boolean)
  };
}
function sendRoom(roomCode) {
  const data = publicRoom(roomCode);
  if (data) io.to(roomCode).emit("room:update", data);
}
function leaveRoom(socket) {
  const p = players.get(socket.id);
  if (!p || !p.room) return;
  const roomCode = p.room;
  const room = rooms.get(roomCode);
  socket.leave(roomCode);
  p.room = null;
  socket.emit("room:left");
  if (room) {
    room.players = room.players.filter(id => id !== socket.id);
    // If a match is unfinished, return each player's locked stake.
    if (room.status === "playing") {
      for (const id of room.players) {
        const other = players.get(id);
        if (other && other.locked) {
          other.gems += room.stake;
          other.locked = false;
          other.ready = false;
        }
      }
    }
    if (room.players.length === 0) rooms.delete(roomCode);
    else {
      room.status = "waiting";
      const remaining = players.get(room.players[0]);
      if (remaining) { remaining.color = null; remaining.ready = false; remaining.locked = false; }
      sendRoom(roomCode);
      io.to(roomCode).emit("notice", "The other player left. The room is open again.");
    }
  }
  io.emit("rooms:list", listRooms());
  emitBalance(socket.id);
}
function listRooms() {
  return [...rooms.entries()]
    .filter(([_, r]) => r.status !== "playing" && r.players.length < 2)
    .map(([roomCode, r]) => ({ code: roomCode, stake: r.stake, players: r.players.length }));
}
function emitBalance(id) {
  const p = players.get(id);
  if (p) io.to(id).emit("balance", p.gems);
}

io.on("connection", socket => {
  players.set(socket.id, { name: "Player" + socket.id.slice(0, 4), gems: 1000, room: null, color: null, ready: false, locked: false });
  emitBalance(socket.id);
  socket.emit("rooms:list", listRooms());

  socket.on("profile:name", name => {
    const p = players.get(socket.id);
    if (!p) return;
    p.name = String(name || "").trim().replace(/[<>]/g, "").slice(0, 18) || p.name;
    if (p.room) sendRoom(p.room);
  });

  socket.on("rooms:list:request", () => socket.emit("rooms:list", listRooms()));

  socket.on("room:create", stakeInput => {
    const p = players.get(socket.id);
    if (!p) return;
    if (p.room) return socket.emit("error:message", "Leave your current room first.");
    const stake = Number(stakeInput);
    if (!Number.isInteger(stake) || stake < 10 || stake > 200) return socket.emit("error:message", "Stake must be 10–200 virtual gems.");
    if (p.gems < stake) return socket.emit("error:message", "You don't have enough virtual gems.");
    let roomCode;
    do { roomCode = code(); } while (rooms.has(roomCode));
    rooms.set(roomCode, { host: socket.id, players: [socket.id], stake, status: "waiting" });
    p.room = roomCode; p.color = "Green"; p.ready = false; p.locked = false;
    socket.join(roomCode);
    socket.emit("room:joined", roomCode);
    sendRoom(roomCode);
    io.emit("rooms:list", listRooms());
  });

  socket.on("room:join", input => {
    const p = players.get(socket.id);
    if (!p) return;
    if (p.room) return socket.emit("error:message", "Leave your current room first.");
    const roomCode = String(input || "").trim().toUpperCase();
    const room = rooms.get(roomCode);
    if (!room || room.status !== "waiting" || room.players.length !== 1) return socket.emit("error:message", "That room isn't available.");
    if (p.gems < room.stake) return socket.emit("error:message", "You don't have enough virtual gems for this stake.");
    p.room = roomCode; p.color = "Red"; p.ready = false; p.locked = false;
    room.players.push(socket.id);
    socket.join(roomCode);
    socket.emit("room:joined", roomCode);
    sendRoom(roomCode);
    io.emit("rooms:list", listRooms());
  });

  socket.on("match:ready", () => {
    const p = players.get(socket.id);
    if (!p || !p.room) return;
    const room = rooms.get(p.room);
    if (!room || room.players.length !== 2 || room.status !== "waiting") return socket.emit("error:message", "Waiting for another player.");
    if (!p.locked) {
      if (p.gems < room.stake) return socket.emit("error:message", "Not enough virtual gems.");
      p.gems -= room.stake;
      p.locked = true;
    }
    p.ready = true;
    emitBalance(socket.id);
    sendRoom(p.room);
    const both = room.players.every(id => {
      const other = players.get(id);
      return other && other.ready && other.locked;
    });
    if (both) {
      room.status = "playing";
      sendRoom(p.room);
      // One server-generated result is shared by both players.
      const winnerColor = crypto.randomInt(0, 2) === 0 ? "Green" : "Red";
      const winnerId = room.players.find(id => players.get(id).color === winnerColor);
      const winner = players.get(winnerId);
      if (winner) { winner.gems += room.stake * 2; winner.locked = false; emitBalance(winnerId); }
      for (const id of room.players) {
        const other = players.get(id);
        if (other) { other.locked = false; other.ready = false; }
      }
      io.to(p.room).emit("match:result", {
        color: winnerColor,
        winner: winner ? winner.name : "Unknown",
        pot: room.stake * 2
      });
      room.status = "finished";
      sendRoom(p.room);
      io.emit("rooms:list", listRooms());
    }
  });

  socket.on("room:leave", () => leaveRoom(socket));
  socket.on("disconnect", () => {
    leaveRoom(socket);
    players.delete(socket.id);
    io.emit("rooms:list", listRooms());
  });
});

server.listen(PORT, () => console.log(`Color Dice running at http://localhost:${PORT}`));
