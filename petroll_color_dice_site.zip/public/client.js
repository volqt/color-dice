const socket = io();
const $ = id => document.getElementById(id);
let currentRoom = null;
let roomState = null;
let hasReadied = false;

function toast(message) {
  $("toast").textContent = message;
  $("toast").classList.remove("hidden");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => $("toast").classList.add("hidden"), 3200);
}
function fmt(n) { return Number(n).toLocaleString(); }

$("saveName").onclick = () => socket.emit("profile:name", $("name").value);
$("name").addEventListener("keydown", e => { if (e.key === "Enter") $("saveName").click(); });
$("create").onclick = () => socket.emit("room:create", Number($("stake").value));
$("refresh").onclick = () => socket.emit("rooms:list:request");
$("join").onclick = () => socket.emit("room:join", $("roomCode").value);
$("roomCode").addEventListener("keydown", e => { if (e.key === "Enter") $("join").click(); });
$("ready").onclick = () => {
  if (!roomState || roomState.players.length !== 2) return;
  hasReadied = true;
  $("ready").disabled = true;
  $("ready").textContent = "Waiting for opponent…";
  socket.emit("match:ready");
};
$("leave").onclick = () => socket.emit("room:leave");

socket.on("balance", gems => $("balance").textContent = fmt(gems));
socket.on("error:message", toast);
socket.on("notice", toast);
socket.on("room:joined", code => {
  $("match").classList.remove("hidden");
  currentRoom = code;
  hasReadied = false;
  $("created").classList.remove("hidden");
  $("created").innerHTML = `Room code: <strong>${code}</strong> — share this code with your opponent.`;
  $("match").classList.remove("hidden");
  $("roomBadge").textContent = code;
  $("result").classList.add("hidden");
  $("dice").textContent = "🎲";
  $("matchInfo").textContent = "Choose ready when both players are in the room.";
});
socket.on("rooms:list", rooms => {
  const el = $("rooms");
  if (!rooms.length) {
    el.innerHTML = '<p class="muted">No open rooms yet. Create one and invite a friend!</p>';
    return;
  }
  el.innerHTML = "";
  rooms.forEach(r => {
    const item = document.createElement("div");
    item.className = "room";
    const details = document.createElement("div");
    details.innerHTML = `<strong>Room ${r.code}</strong><br><small>💎 ${r.stake} gems • ${r.players}/2 players</small>`;
    const join = document.createElement("button");
    join.textContent = "Join";
    join.onclick = () => socket.emit("room:join", r.code);
    item.append(details, join);
    el.append(item);
  });
});
socket.on("room:update", room => {
  roomState = room;
  currentRoom = room.code;
  $("match").classList.remove("hidden");
  $("roomBadge").textContent = `${room.code} • 💎 ${room.stake} each`;
  const green = room.players.find(p => p.color === "Green");
  const red = room.players.find(p => p.color === "Red");
  $("greenName").textContent = green ? green.name : "Waiting for host…";
  $("redName").textContent = red ? red.name : "Waiting for opponent…";
  $("greenReady").textContent = green ? (green.ready ? "Ready ✓" : "Not ready") : "Open seat";
  $("redReady").textContent = red ? (red.ready ? "Ready ✓" : "Not ready") : "Open seat";
  $("ready").disabled = room.players.length !== 2 || hasReadied || room.status !== "waiting";
  $("ready").textContent = hasReadied ? "Waiting for opponent…" : "I'm ready";
  $("matchInfo").textContent = room.players.length < 2
    ? "Share the room code and wait for another player."
    : "Both players must press Ready. The server rolls one shared result.";
});
socket.on("match:result", result => {
  $("dice").textContent = result.color === "Green" ? "🟢🎲" : "🔴🎲";
  $("result").classList.remove("hidden");
  $("result").textContent = `${result.color.toUpperCase()} WINS! ${result.winner} gets ${fmt(result.pot)} virtual gems.`;
  $("matchInfo").textContent = "Match complete. Leave the room to start or join another match.";
  $("ready").disabled = true;
  hasReadied = false;
});
socket.on("disconnect", () => toast("Disconnected. Reconnecting…"));
socket.on("connect", () => socket.emit("rooms:list:request"));
socket.on("room:left", () => {
  currentRoom = null;
  roomState = null;
  hasReadied = false;
  $("match").classList.add("hidden");
  $("created").classList.add("hidden");
  $("ready").textContent = "I'm ready";
  $("result").classList.add("hidden");
  socket.emit("rooms:list:request");
});


// Make the duel panel behave like a modal while keeping the room visible.
document.querySelectorAll('a[href="#color-dice"]').forEach(link => {
  link.addEventListener("click", () => {
    // Scroll to the room creator; opening a room itself opens the match modal.
  });
});
document.addEventListener("keydown", event => {
  if (event.key === "Escape" && currentRoom) {
    // Do not silently leave a live room when the user presses Escape.
    $("match").classList.remove("hidden");
  }
});
